from .main import bot
